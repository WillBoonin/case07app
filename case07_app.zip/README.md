# Case 07 Azure Blob Flask App
This Flask app exposes two endpoints:
- `/api/v1/health` — verifies the app is running.
- `/api/v1/upload` — uploads a JSON file to Azure Blob Storage.
